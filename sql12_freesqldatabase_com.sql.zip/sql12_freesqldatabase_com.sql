-- phpMyAdmin SQL Dump
-- version 4.7.1
-- https://www.phpmyadmin.net/
--
-- Host: sql12.freesqldatabase.com
-- Generation Time: Jun 11, 2020 at 09:45 AM
-- Server version: 5.5.62-0ubuntu0.14.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql12337112`
--
CREATE DATABASE IF NOT EXISTS `sql12337112` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sql12337112`;

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `time` varchar(240) DEFAULT NULL,
  `day` varchar(240) DEFAULT NULL,
  `month` varchar(240) DEFAULT NULL,
  `doctorname` varchar(240) DEFAULT NULL,
  `patientname` varchar(240) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enquiryData`
--

CREATE TABLE `enquiryData` (
  `enquiryid` int(11) NOT NULL,
  `enquiryType` enum('General Enquiry','Follow-up Enquiry','Emergency Enquiry','Feedback') NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `phoneNumber` varchar(10) NOT NULL,
  `apptID` varchar(10) NOT NULL,
  `message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forgotPassword`
--

CREATE TABLE `forgotPassword` (
  `forgotPasswordId` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `medicalsubscriptions`
--

CREATE TABLE `medicalsubscriptions` (
  `medicalsubscriptionsID` int(11) NOT NULL,
  `pat_firstname` text NOT NULL,
  `pat_lastname` text NOT NULL,
  `pat_email` varchar(200) NOT NULL,
  `apptId` varchar(10) NOT NULL,
  `consultationType` enum('General Consultation','Pre-surgery Consultation','Emergency','Recurring') NOT NULL,
  `consultationSummary` longtext NOT NULL,
  `recommendation` longtext NOT NULL,
  `referralNotice` mediumtext NOT NULL,
  `prescription` mediumtext NOT NULL,
  `doc_firstname` text NOT NULL,
  `doc_lastname` text NOT NULL,
  `doc_email` varchar(100) NOT NULL,
  `doc_phonenumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `referral`
--

CREATE TABLE `referral` (
  `id` int(11) NOT NULL,
  `pat_firstname` text NOT NULL,
  `pat_lastname` text NOT NULL,
  `pat_email` varchar(200) NOT NULL,
  `consultationSummay` longtext NOT NULL,
  `doc_firstname` text NOT NULL,
  `doc_lastname` text NOT NULL,
  `doc_email` varchar(200) NOT NULL,
  `doc_phonenumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `urgentcases`
--

CREATE TABLE `urgentcases` (
  `id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `emergencytype` enum('Pre-Surgery','Deterioration in Condition','Prescribed Medication Repeat','Other') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `firstname` varchar(240) DEFAULT NULL,
  `lastname` varchar(240) DEFAULT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `address` varchar(500) NOT NULL,
  `username` varchar(240) DEFAULT NULL,
  `password` varchar(240) DEFAULT NULL,
  `usertype` varchar(240) DEFAULT NULL,
  `doctorid` varchar(240) DEFAULT NULL,
  `lang` enum('English','Mandarin','Arabic','Cantonese','Vietnamese','Italian','Greek','Tagalog','Hindi','Spanish','Punjabi') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`firstname`, `lastname`, `phonenumber`, `address`, `username`, `password`, `usertype`, `doctorid`, `lang`) VALUES
('michael', 'scott', '', '', 'michael@scott', 'office', 'patient', 'none', 'English'),
('michael', 'scott', '', '', 'michael@doctor', 'clinic', 'patient', 'none', 'English'),
('michael', 'scott', '', '', 'michael@doctor', 'clinic', 'Doctor', '123', 'English'),
('michael', 'scott', '', '', 'michael@doctor', 'clinic', 'Doctor', '123', 'English'),
('different', 'name', '', '', 'doctor', 'doctor', 'patient', 'none', 'English'),
('monkey', 'man ', '', '', 'monkey', 'monkey', 'Doctor', '789', 'English'),
('micahel', 'scott', '', '', 'Admin', 'password', 'patient', 'none', 'English'),
('', '', '', '', '', '', 'patient', 'none', ''),
('johnathan', 'smile', '04030303', 'iu4nurvb3oi', 'john.smile@gmail.com', 'Password1', 'patient', 'none', 'English'),
('michael', 'phill', '058383949', '4/6 Mont street, Liverpool', '', 'Password1', 'Doctor', '405393949', 'English'),
('michael', 'phill', '0405i4949', '405-593993', '', 'Password1', 'Doctor', '540949', 'English'),
('michael', 'phill', '5040495', '50405505', 'michael.phill@gmail.com', 'Password1', 'Doctor', '540949', 'English'),
('James', 'John', '04030303', '2 Liverpool Street Liverpool', 'james.john@gmail.com', 'Password1', 'patient', 'none', 'English'),
('Ethan', 'Phill', '04837374', '4 Moo Street Penrith', 'ethan.phill@gmail.com', 'Password1', 'Doctor', '933747383', 'English'),
('Jake', 'Ethan', '04030303', '4 Liverpool Street, Liverpool', 'jake.ethan@gmail.com', 'Password1', 'patient', 'none', 'English'),
('Jake', 'Andrew', '', '4 Liverpool Street, Liverpool', 'jake.andrew@gmail.com', 'Password1', 'patient', 'none', 'English'),
('Jake', 'Ethan', '04030303', '4 Liverpool Street, Liverpool', 'jake.ethan@gmail.com', 'Password1', 'patient', 'none', 'English'),
('Jake', 'Matthew', '04030303', '4 Liverpool Street, Liverpool', 'jake.matthew@gmail.com', 'Password1', 'patient', 'none', 'English'),
('Jake', 'Phill', '0418381293', '6 Liverpool Street, Liverpool', 'jake.phill@gmail.com', 'Password1', 'Doctor', '540949', 'English'),
('Marie', 'Curie', '0462876290', 'Building 11 University of Technology Sydney 81, Broadway, Ultimo NSW 2007', 'marie.curie@medicalcentre.com', 'curiemarie', 'Doctor', '980877923', 'English');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquiryData`
--
ALTER TABLE `enquiryData`
  ADD PRIMARY KEY (`enquiryid`);

--
-- Indexes for table `forgotPassword`
--
ALTER TABLE `forgotPassword`
  ADD PRIMARY KEY (`forgotPasswordId`);

--
-- Indexes for table `medicalsubscriptions`
--
ALTER TABLE `medicalsubscriptions`
  ADD PRIMARY KEY (`medicalsubscriptionsID`);

--
-- Indexes for table `referral`
--
ALTER TABLE `referral`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `urgentcases`
--
ALTER TABLE `urgentcases`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquiryData`
--
ALTER TABLE `enquiryData`
  MODIFY `enquiryid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forgotPassword`
--
ALTER TABLE `forgotPassword`
  MODIFY `forgotPasswordId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `medicalsubscriptions`
--
ALTER TABLE `medicalsubscriptions`
  MODIFY `medicalsubscriptionsID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `referral`
--
ALTER TABLE `referral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `urgentcases`
--
ALTER TABLE `urgentcases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
